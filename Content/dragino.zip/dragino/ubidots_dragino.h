/*
Ubidots.cpp -El objetivo de la librería es realizar la conexión con la plataforma ubidots, para que los usuarios puedan postear o escribir su información 
en la nube


*/
#ifndef Ubidots_dragino_h
#define Ubidots_dragino_h
#include "arduino.h"
#include <Process.h>

class Ubidots {
  public:
   Ubidots(String apikey);
   String get_value(String idvariable);
   boolean save_value(String idvariable,String valor);    
   boolean ubitoken();
 
  private: 
   
   int flag;    	
   String token;
   char c;
   String value;
};

#endif